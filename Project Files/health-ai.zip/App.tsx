
import React from 'react';
import ChatWindow from './components/ChatWindow';
import Header from './components/Header';
import Disclaimer from './components/Disclaimer';

const App: React.FC = () => {
  return (
    <div className="flex flex-col h-screen font-sans bg-gray-50 text-gray-800">
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-4 overflow-hidden">
        <div className="w-full max-w-4xl h-full flex flex-col bg-white rounded-2xl shadow-xl border border-gray-200">
          <ChatWindow />
        </div>
      </main>
      <Disclaimer />
    </div>
  );
};

export default App;
