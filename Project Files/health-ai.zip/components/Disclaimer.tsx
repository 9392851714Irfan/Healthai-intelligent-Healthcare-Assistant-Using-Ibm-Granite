
import React from 'react';
import { WarningIcon } from '../constants';

const Disclaimer: React.FC = () => {
  return (
    <footer className="w-full bg-yellow-100 border-t-2 border-yellow-300 p-3 text-center text-sm text-yellow-800">
      <div className="max-w-4xl mx-auto flex items-center justify-center space-x-2">
        <WarningIcon className="w-5 h-5 flex-shrink-0" />
        <p>
          <strong>Disclaimer:</strong> Health AI provides information for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. Do not share sensitive personal health information.
        </p>
      </div>
    </footer>
  );
};

export default Disclaimer;
