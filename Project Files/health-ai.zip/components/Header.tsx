
import React from 'react';
import { AiIcon } from '../constants';

const Header: React.FC = () => {
  return (
    <header className="w-full bg-white shadow-sm border-b border-gray-200 p-4 flex items-center justify-center">
      <div className="flex items-center space-x-3">
        <AiIcon className="w-8 h-8 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800 tracking-tight">Health AI</h1>
      </div>
    </header>
  );
};

export default Header;
