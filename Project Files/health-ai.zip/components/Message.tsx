
import React from 'react';
import { Message as MessageType } from '../types';
import { UserIcon, AiIcon } from '../constants';
import Loader from './Loader';

interface MessageProps {
  message: MessageType;
  isLoading?: boolean;
}

const Message: React.FC<MessageProps> = ({ message, isLoading = false }) => {
  const isUser = message.sender === 'user';

  const avatar = isUser ? (
    <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
      <UserIcon className="w-5 h-5 text-slate-500" />
    </div>
  ) : (
    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
      <AiIcon className="w-5 h-5 text-white" />
    </div>
  );

  return (
    <div className={`flex items-start gap-3 my-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className="flex-shrink-0 mt-1">{avatar}</div>
      <div
        className={`rounded-2xl p-4 max-w-lg shadow-sm ${
          isUser
            ? 'bg-blue-600 text-white rounded-br-none'
            : 'bg-gray-100 text-gray-800 rounded-bl-none border border-gray-200'
        }`}
      >
        {isLoading ? <Loader /> : <p className="whitespace-pre-wrap">{message.text}</p>}
      </div>
    </div>
  );
};

export default Message;
