
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Chat } from '@google/genai';
import { Message as MessageType } from '../types';
import { createChat, sendMessageToAI } from '../services/geminiService';
import Message from './Message';
import InputBar from './InputBar';
import { AiIcon } from '../constants';

const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: 'init',
      text: "Hello! I'm Health AI. How can I help you today? You can ask me about symptoms, medical conditions, or general health topics.",
      sender: 'ai',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const chatRef = useRef<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize chat on component mount
    chatRef.current = createChat();
  }, []);

  useEffect(() => {
    // Scroll to the bottom when new messages are added
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!chatRef.current) return;
    setIsLoading(true);

    const userMessage: MessageType = { id: Date.now().toString(), text, sender: 'user' };
    
    // Add user message and a temporary loading message for the AI
    setMessages(prev => [...prev, userMessage, { id: 'loading', text: '', sender: 'ai' }]);

    try {
      const aiResponseText = await sendMessageToAI(chatRef.current, text);
      const aiMessage: MessageType = { id: (Date.now() + 1).toString(), text: aiResponseText, sender: 'ai' };
      
      // Replace loading message with actual AI response
      setMessages(prev => [...prev.slice(0, -1), aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: MessageType = { 
          id: (Date.now() + 1).toString(), 
          text: "I'm having trouble connecting right now. Please try again later.", 
          sender: 'ai' 
      };
      setMessages(prev => [...prev.slice(0, -1), errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="flex flex-col h-full">
      <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-6">
        {messages.map((msg, index) => (
           <Message key={msg.id} message={msg} isLoading={isLoading && index === messages.length - 1} />
        ))}
         {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
                <AiIcon className="w-16 h-16 mb-4"/>
                <p className="text-lg">Welcome to Health AI</p>
                <p>Start a conversation by typing below.</p>
            </div>
        )}
      </div>
      <InputBar onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default ChatWindow;
